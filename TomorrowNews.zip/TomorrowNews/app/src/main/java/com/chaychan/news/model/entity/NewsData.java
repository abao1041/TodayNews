package com.chaychan.news.model.entity;

/**
 * @author ChayChan
 * @description: TODO
 * @date 2017/7/6  15:32
 */

public class NewsData {
    /**
     * content : {"log_pb": {"impr_id": "20170706150300010008035045972312"}, "read_count": 14173284, "ban_comment": 0, "abstract": "\u4e60\u8fd1\u5e73\u51fa\u8bbf\u4fc4\u7f57\u65af\u5fb7\u56fd\u5e76\u51fa\u5e2dG20\u6c49\u5821\u5cf0\u4f1a", "image_list": [], "ban_bury": 1, "ugc_recommend": {"reason": "", "activity": ""}, "article_type": 1, "tag": "news_world", "forward_info": {"forward_count": 117}, "has_m3u8_video": 0, "keywords": "\u4e60\u8fd1\u5e73,\u4fc4\u7f57\u65af", "rid": "20170706150300010008035045972312", "label": "\u7f6e\u9876", "show_portrait_article": false, "user_verified": 0, "aggr_type": 1, "cell_type": 0, "article_sub_type": 0, "bury_count": 0, "title": "\u4e60\u8fd1\u5e73\u5411\u4e16\u754c\u5c55\u793a\u201c\u4e2d\u56fd\u540d\u7247\u201d", "ignore_web_transform": 1, "source_icon_style": 1, "tip": 0, "hot": 0, "share_url": "http://toutiao.com/group/6438349797672878594/?iid=0&app=news_article", "has_mp4_video": 0, "source": "\u4e13\u9898", "comment_count": 153, "article_url": "http://a3.pstatp.com/subject2/6438349797672878594/?version=0", "filter_words": [], "share_count": 7620, "stick_label": "\u7f6e\u9876", "publish_time": 1499069079, "action_list": [{"action": 1, "extra": {}, "desc": ""}, {"action": 3, "extra": {}, "desc": ""}, {"action": 7, "extra": {}, "desc": ""}, {"action": 9, "extra": {}, "desc": ""}], "has_image": false, "cell_layout_style": 1, "tag_id": 6438349797672878594, "video_style": 0, "verified_content": "", "display_url": "http://a3.pstatp.com/subject2/6438349797672878594/?version=0", "is_stick": true, "large_image_list": [], "like_count": 219, "item_id": 6438349800936047105, "is_subject": true, "stick_style": 1, "show_portrait": false, "repin_count": 99633, "cell_flag": 11, "source_open_url": "sslocal://search?from=feed_source&keyword=%E4%B8%93%E9%A2%98", "level": 0, "source_avatar": "http://p9.pstatp.com/medium/dd30000ce5593c8c44a", "digg_count": 219, "behot_time": 1499324580, "article_alt_url": "http://toutiao.com/group/article/6438349797672878594/", "cursor": 1499324580999, "url": "http://a3.pstatp.com/subject2/6438349797672878594/?version=0", "preload_web": 0, "user_repin": 0, "label_style": 1, "item_version": 0, "has_video": false, "group_id": 6438349797672878594, "middle_image": {}}
     * code :
     */

    public String content;
    public String code;
}
