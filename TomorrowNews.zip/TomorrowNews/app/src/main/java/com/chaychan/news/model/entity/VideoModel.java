package com.chaychan.news.model.entity;

import java.util.List;

/**
 * @author ChayChan
 * @date 2017/6/18  19:37
 */
public class VideoModel {
    public List<Video> video;
}
