package com.chaychan.news.model.entity;

/**
 * Created by Administrator on 2016/11/22 0022.
 */
public class Comment {


    /**
     * id : 1571509257847810
     * text : 那叫莲花落别拿喊麦侮辱我大丐帮
     * reply_count : 0
     * reply_list : []
     * digg_count : 1
     * bury_count : 0
     * create_time : 1498708017
     * score : 0.3516180217266083
     * user_id : 5828236855
     * user_name : sedric
     * user_profile_image_url : http://p3.pstatp.com/thumb/1dcf000cd40a383dcb13
     * user_verified : false
     * is_following : 0
     * is_followed : 0
     * is_blocking : 0
     * is_blocked : 0
     * is_pgc_author : 0
     * author_badge : []
     * verified_reason :
     * user_bury : 0
     * user_digg : 0
     * user_relation : 0
     * user_auth_info :
     * media_info : {"name":"","avatar_url":""}
     * reply_to_comment : {"id":1571508516773889,"text":"这不是旧社会讨饭的时候唱的乞丐歌吗？现在改成喊麦了？乞丐现在都活在网上了吗？","user_id":3094042528,"user_name":"小猴子的王先生","user_profile_image_url":"http://p1.pstatp.com/thumb/1a6a000c92a37e79a505","user_verified":false,"is_pgc_author":0,"is_following":0,"is_followed":0,"user_relation":0}
     * platform : feifei
     */

    public String text;
    public int digg_count;
    public String user_name;
    public String user_profile_image_url;
    public long create_time;
}
