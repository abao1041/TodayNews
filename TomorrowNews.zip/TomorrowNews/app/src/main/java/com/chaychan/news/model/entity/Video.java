package com.chaychan.news.model.entity;

/**
 * @author ChayChan
 * @description: 视频的实体类
 * @date 2017/6/18  19:37
 */
public class Video {
   public String url;
   public String desc;
   public String thumb;
}
