package com.chaychan.news.model.entity;

/**
 * @author ChayChan
 * @description: 新闻图片的实体类
 * @date 2017/6/18  19:51
 */

public class ImageUrl {
    public String url;
}
