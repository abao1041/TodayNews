package com.chaychan.news.model.entity;

/**
 * @author ChayChan
 * @date 2017/6/29  17:22
 */

public class CommentData {
    /**
     * comment : {"id":1571513135336450,"text":"很多女人都说和老公好好聊聊，其实就是和老公吵架，你越和老公吵架，老公越不会往你这边靠。","reply_count":17,"reply_list":[{"id":1571515070744578,"text":"队","user_id":59555636592,"user_name":"小银说事","user_verified":false,"user_auth_info":"","is_pgc_author":1,"author_badge":[{"url":"http://p1.pstatp.com/large/c08000f223c4bf564b9.png","open_url":"","width":78,"height":42,"url_list":[{"url":"http://p2.pstatp.com/large/c08000f223c4bf564b9.png"},{"url":"http://p3.pstatp.com/large/c08000f223c4bf564b9.png"},{"url":"http://p4.pstatp.com/large/c08000f223c4bf564b9.png"}],"uri":"large/c08000f223c4bf564b9.png"}]},{"id":1571516187533313,"text":"胸大无脑，很多时候都是女人亲自一步步把老公的心推出这个家，反而过后装作两眼茫然，一脸无辜","user_id":6362248770,"user_name":"漂泊尘","user_verified":false,"user_auth_info":"","is_pgc_author":0,"author_badge":[]},{"id":1571522212933650,"text":"我就想骂了\u2026\u2026男人要犯贱的时候女人做什么都是错的","user_id":61716324337,"user_name":"法海不懂爱173580759","user_verified":false,"user_auth_info":"","is_pgc_author":0,"author_badge":[]}],"digg_count":217,"bury_count":0,"create_time":1498711715,"score":0.4305717647075653,"user_id":3634071107,"user_name":"雨20359066","user_profile_image_url":"http://p1.pstatp.com/thumb/2171/6003290650","user_verified":false,"is_following":0,"is_followed":0,"is_blocking":0,"is_blocked":0,"is_pgc_author":0,"author_badge":[],"verified_reason":"","user_bury":0,"user_digg":0,"user_relation":0,"user_auth_info":"","media_info":{"name":"","avatar_url":""},"platform":"feifei"}
     * cell_type : 1
     */

    public Comment comment;
}
