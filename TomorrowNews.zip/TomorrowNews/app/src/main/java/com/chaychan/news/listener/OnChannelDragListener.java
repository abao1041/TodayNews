package com.chaychan.news.listener;

import com.chad.library.adapter.base.BaseViewHolder;

/**
 * Created by Administrator on 2017/1/5 0005.
 */

public interface OnChannelDragListener extends OnChannelListener {
    void onStarDrag(BaseViewHolder baseViewHolder);

}
